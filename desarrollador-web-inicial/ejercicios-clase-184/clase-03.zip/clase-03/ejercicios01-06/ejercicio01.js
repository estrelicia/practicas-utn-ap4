/*
// let consulta = prompt("Escribe algo aquí y te devolveré el tipo de dato que es:");
*/

function tipoDato (dato) {
   return console.log (typeof (dato));
 }	

let a = true;
let b = 23;
let c = "hola"; 
let d = 55.5;
let e = null;

tipoDato(a);
tipoDato(b);
tipoDato(c);
tipoDato(d);
tipoDato(e);
