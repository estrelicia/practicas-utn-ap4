let numero1 = prompt('Ingrese el primer número');
let numero2 = prompt('Ingrese el segundo número');

function restaNumeros (num1,num2) {
    let resta = num1-num2;
    return resta;
};

console.log(restaNumeros(numero1,numero2));